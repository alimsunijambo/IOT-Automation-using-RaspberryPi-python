#!/bin/bash
sudo apt-get update

sudo apt-get install python

sudo apt-get install python-pip

sudo pip uninstall pubnub
sudo pip install pubnub==3.9

sudo apt-get install python-picamera
sudo apt-get install python-picamera-docs

sudo pip install twilio
sudo apt-get install i2c-tools
